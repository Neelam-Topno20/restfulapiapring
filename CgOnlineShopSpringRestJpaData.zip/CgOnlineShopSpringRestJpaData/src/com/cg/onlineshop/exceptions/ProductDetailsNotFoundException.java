package com.cg.onlineshop.exceptions;

public class ProductDetailsNotFoundException extends Exception {

	public ProductDetailsNotFoundException() {
		super();
	}

	public ProductDetailsNotFoundException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
	}

	public ProductDetailsNotFoundException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	public ProductDetailsNotFoundException(String arg0) {
		super(arg0);
	}

	public ProductDetailsNotFoundException(Throwable arg0) {
		super(arg0);
	}

}
