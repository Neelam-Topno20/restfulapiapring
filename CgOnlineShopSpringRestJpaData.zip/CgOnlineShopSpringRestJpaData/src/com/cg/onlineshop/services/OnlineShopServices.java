package com.cg.onlineshop.services;

import java.util.List;
import java.util.Optional;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;



public interface OnlineShopServices {
 Product acceptProductDetails(Product product);
 List<Product> getAllProductDetails();
 Product getProductDetails(int productId)throws ProductDetailsNotFoundException;
 void removeProductDetails(int productId);
}
